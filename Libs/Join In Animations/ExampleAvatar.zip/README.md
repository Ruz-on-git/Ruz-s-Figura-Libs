# Join In Animations
An animation libary for figura
