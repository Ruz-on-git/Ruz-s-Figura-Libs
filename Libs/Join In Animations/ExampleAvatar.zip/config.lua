---@class JCConfig
---@field MARKER_PREFIX string
---@field MAX_PAYLOAD_LENGTH number
---@field CHECKER { MAX_TICKS: number, MARKER_PREFIX: string }
---@field LOGTYPES { ERROR: string, WARNING: string, LOG: string }
---@field LOG_PREFIX_JSON string
---@field COMMANDS {PREFIX: string, ROOT: { name: string, aliases: string[] }}

---@class OAPaths
---@field dataDirectory string
---@field manifestFile string

---@class OAData
---@field modelParts table<string, ModelPart>
---@field defaultTypes table<string, string>

---@class OAConfig
---@field paths OAPaths
---@field data OAData
---@field LOG_PREFIX_JSON string
---@field CURRENT_ANIMATION_KEY string
---@field TICKS_PER_SECOND number
---@field MAX_BYTES_PER_SECOND number
---@field PRECISION number

---@class JIAData
---@field requestTimeoutTime number

---@class JIAConfig
---@field LOG_PREFIX_JSON string
---@field data JIAData

---@class ConfigPaths
---@field APIFolder string
---@field SimpleWheels string
---@field ExtendedJson string
---@field WhitelistMe string
---@field JustCommunicate table
---@field OffloadAnimations table
---@field JoinInAnimations string
---@field RuzUtils table

---@class MainConfig
---@field paths ConfigPaths
---@field JustCommunicate JCConfig
---@field OffloadAnimations OAConfig
---@field JoinInAnimations JIAConfig

---@type MainConfig
---@diagnostic disable-next-line
local config = {}
---@diagnostic disable-next-line
config.paths = {}
local p = config.paths

p.APIFolder = "APIs"

p.SimpleWheels = p.APIFolder .. ".SimpleWheels"
p.ExtendedJson = p.APIFolder .. ".ExtendedJson"
p.WhitelistMe = p.APIFolder .. ".WhitelistMe"
p.JoinInAnimations = p.APIFolder .. ".JoinInAnimations"

p.JustCommunicate = {Folder = p.APIFolder .. ".JustCommunicate"}
p.JustCommunicate.API = p.JustCommunicate.Folder .. ".API"
p.JustCommunicate.Commands = p.JustCommunicate.Folder .. ".commands"
p.JustCommunicate.Messaging = p.JustCommunicate.Folder .. ".messaging"

p.OffloadAnimations = {Folder = p.APIFolder .. ".OffloadAnimations"}
p.OffloadAnimations.API = p.OffloadAnimations.Folder .. ".API"
p.OffloadAnimations.Codec = p.OffloadAnimations.Folder .. ".codec"
p.OffloadAnimations.Interpolation = p.OffloadAnimations.Folder .. ".interpolation"
p.OffloadAnimations.Loader = p.OffloadAnimations.Folder .. ".loader"
p.OffloadAnimations.Player = p.OffloadAnimations.Folder .. ".player"
p.OffloadAnimations.LocalPlayer = p.OffloadAnimations.Folder .. ".localPlayer"
p.OffloadAnimations.Stream = p.OffloadAnimations.Folder .. ".stream"

p.RuzUtils = { Folder = p.APIFolder .. ".RuzsUtils"}
p.RuzUtils.API = p.RuzUtils.Folder .. ".API"
p.RuzUtils.CommandManager = p.RuzUtils.Folder .. ".commandManager"

config.JustCommunicate = {
    MARKER_PREFIX = "[JUST_COMM_MSG]",
    MAX_PAYLOAD_LENGTH = 16000,

    CHECKER = {
        MAX_TICKS = 100,
        MARKER_PREFIX = "[JustCommunicate][Internal]:"
    },

    LOGTYPES = {
        ERROR = "red",
        WARNING = "yellow",
        LOG = "white"
    },

    LOG_PREFIX_JSON = table.concat({
        '{"text":"[","color":"white"}',
        '{"text":"Just","color":"green"}',
        '{"text":"Communicate","color":"dark_green"}',
    }, ","),

    COMMANDS = {
        PREFIX = ".",
        ROOT = {
            name = "jc",
            aliases = { "jc", "justcommunicate" }
        },
        SUBCOMMANDS = {
            help = {
                aliases = { "help", "?" },
                desc = "Shows the help menu."
            },
            
            whitelist = {
                aliases = { "wl", "whitelist" },
                desc = "Manage whitelist manually.",
                subcommands = {
                    add = { desc = "Add a player/UUID.", usage = "<name/uuid>" },
                    remove = { desc = "Remove a player/UUID.", usage = "<name/uuid>" },
                    set = { desc = "Set global mode.", usage = "<*|all|none>" },
                    list = { desc = "List whitelisted players." }
                }
            },

            whitelistLooking = {
                aliases = { "wll", "looking" },
                desc = "Manage whitelist for the entity you are looking at.",
                subcommands = {
                    add = { desc = "Add the target entity." },
                    remove = { desc = "Remove the target entity." }
                }
            }
        }
    }
}

config.OffloadAnimations = {
    paths = {
        dataDirectory = "offloadAnimations_Data/",
        manifestFile = "manifest.json"
    },

    data = {
        modelParts = {
            root = models.model.root,
            head = models.model.root.Head,
            body = models.model.root.Body,
            leftArm = models.model.root.LeftArm,
            rightArm = models.model.root.RightArm,
            leftLeg = models.model.root.LeftLeg,
            rightLeg = models.model.root.RightLeg,
        },

        defaultTypes = {},
    },

    CURRENT_ANIMATION_KEY = "OA_CurrentAnimation",
    TICKS_PER_SECOND = 20,
    LOG_PREFIX_JSON ='{"text":"[","color":"white"},{"text":"Offload","color":"gold"},{"text":"Animations","color":"yellow"}',
    MAX_BYTES_PER_SECOND = 800,
    PRECISION = 1000.0, 
}

for name, part in pairs(config.OffloadAnimations.data.modelParts) do
    config.OffloadAnimations.data.defaultTypes[name] = part:getParentType()
end

config.JoinInAnimations = {
    LOG_PREFIX_JSON = table.concat({
        '{"text":"[","color":"white"}',
        '{"text":"Join","color":"aqua"}',
        '{"text":"In","color":"blue"}',
        '{"text":"Animations","color":"aqua"}',
    }, ","),

    data = {
        requestTimeoutTime = 100
    }
}

return config
