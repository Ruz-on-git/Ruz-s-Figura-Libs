local cfg = require("config")

---@type JoinInAnimations
local JoinInAnimations = require(cfg.paths.JoinInAnimations)
---@type OffloadAnimations
local OffloadAnimations = require(cfg.paths.OffloadAnimations.API)
---@type RuzUtilsAPI
local RuzUtils = require(cfg.paths.RuzUtils.API)
---@type SimpleWheels
local SimpleWheels = require(cfg.paths.SimpleWheels)

if host:isHost() then 
    local animationPage = SimpleWheels:createPage({
        title = "Join in Animations",
        item = "minecraft:paper",
    })

    SimpleWheels:addAction(animationPage,{
        title = "Stop Animation",
        item = "minecraft:barrier",
        onLeftClick = function()
            OffloadAnimations.stopAnimations()
        end
    })
    
    local modelAnimations = OffloadAnimations.getAllAnimationNames()
    for _, animationName in ipairs(modelAnimations) do
        SimpleWheels:addAction(animationPage,{
            title = animationName,
            item = "minecraft:paper",
            onLeftClick = function()
                local target = RuzUtils.getLookingAtEntity(20)
                if not target or not target:getName() then return end

                JoinInAnimations.request(target:getName(), animationName, "player1", "player2")
            end
        })
    end
end

vanilla_model.PLAYER:setVisible(false)