if not host:isHost() then return end

local WheelManager = {}
local pages = {}
local mainPage = action_wheel:newPage()
local previousPageData = {}

local function back()
    if previousPageData.page then
        action_wheel:setPage(previousPageData.page)
        action_wheel.rightClick = previousPageData.rightClick
    end
end

function WheelManager:init()
    action_wheel:setPage(mainPage)
end

--- Creates a new page and adds a button for it on the main menu.
---@param config table Must contain `title` (string) and `item` (string).
---@return table The created page object with an `addAction` method.
function WheelManager:createPage(config)
    local page = action_wheel:newPage()
    pages[config.title] = page

    page:newAction():title("§lBack"):item("minecraft:arrow"):color(0.8, 0.8, 0.8):onLeftClick(back)
    mainPage:newAction():title(config.title):item(config.item):onLeftClick(function()
        previousPageData.page = action_wheel:getCurrentPage()
        previousPageData.rightClick = action_wheel.rightClick
        action_wheel.rightClick = back
        action_wheel:setPage(page)
    end)
    
    return {
        _page = page,
        --- Adds an action to this page.
        ---@param actionConfig table Configuration for the action.
        addAction = function(self, actionConfig)
            local action = self._page:newAction():title(actionConfig.title):item(actionConfig.item or "minecraft:stone")
            action:color(0.2, 0.2, 0.2)

            if actionConfig.onLeftClick then
                action:onLeftClick(actionConfig.onLeftClick)
           
            elseif actionConfig.onToggle then
                action:onToggle(actionConfig.onToggle)
            end 
            return self
        end
    }
end

WheelManager:init()

return WheelManager