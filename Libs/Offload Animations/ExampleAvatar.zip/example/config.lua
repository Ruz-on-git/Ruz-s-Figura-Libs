---@class OAPaths
---@field dataDirectory string
---@field manifestFile string

---@class OAData
---@field modelParts table<string, ModelPart>
---@field defaultTypes table<string, string>

---@class OAConfig
---@field paths OAPaths
---@field data OAData
---@field LOG_PREFIX_JSON string
---@field CURRENT_ANIMATION_KEY string
---@field TICKS_PER_SECOND number
---@field MAX_BYTES_PER_SECOND number
---@field PRECISION number

---@class ConfigPaths
---@field APIFolder string
---@field SimpleWheels string
---@field ExtendedJson string
---@field OffloadAnimations table
---@field RuzUtils table

---@class MainConfig
---@field paths ConfigPaths
---@field OffloadAnimations OAConfig

---@type MainConfig
---@diagnostic disable-next-line
local config = {}
---@diagnostic disable-next-line
config.paths = {}
local p = config.paths

p.APIFolder = "APIs"

p.SimpleWheels = p.APIFolder .. ".SimpleWheels"
p.ExtendedJson = p.APIFolder .. ".ExtendedJson"

p.OffloadAnimations = {Folder = p.APIFolder .. ".OffloadAnimations"}
p.OffloadAnimations.API = p.OffloadAnimations.Folder .. ".API"
p.OffloadAnimations.Codec = p.OffloadAnimations.Folder .. ".codec"
p.OffloadAnimations.Interpolation = p.OffloadAnimations.Folder .. ".interpolation"
p.OffloadAnimations.Loader = p.OffloadAnimations.Folder .. ".loader"
p.OffloadAnimations.Player = p.OffloadAnimations.Folder .. ".player"
p.OffloadAnimations.LocalPlayer = p.OffloadAnimations.Folder .. ".localPlayer"
p.OffloadAnimations.Stream = p.OffloadAnimations.Folder .. ".stream"

p.RuzUtils = { Folder = p.APIFolder .. ".RuzsUtils"}
p.RuzUtils.API = p.RuzUtils.Folder .. ".API"
p.RuzUtils.CommandManager = p.RuzUtils.Folder .. ".commandManager"

config.OffloadAnimations = {
    paths = {
        dataDirectory = "offloadAnimations_Data/",
        manifestFile = "manifest.json"
    },

    data = {
        modelParts = {
            root = models.model.root,
            head = models.model.root.Head,
            body = models.model.root.Body,
            leftArm = models.model.root.LeftArm,
            rightArm = models.model.root.RightArm,
            leftLeg = models.model.root.LeftLeg,
            rightLeg = models.model.root.RightLeg,
        },

        defaultTypes = {},
    },

    CURRENT_ANIMATION_KEY = "OA_CurrentAnimation",
    TICKS_PER_SECOND = 20,
    LOG_PREFIX_JSON ='{"text":"[","color":"white"},{"text":"Offload","color":"gold"},{"text":"Animations","color":"yellow"}',
    MAX_BYTES_PER_SECOND = 800,
    PRECISION = 1000.0, 
}

for name, part in pairs(config.OffloadAnimations.data.modelParts) do
    config.OffloadAnimations.data.defaultTypes[name] = part:getParentType()
end

return config
