local OffloadAnimations = require("APIs.OffloadAnimations.API")
local SimpleWheels = require("APIs.SimpleWheels")


if host:isHost() then 
    local animationPage = SimpleWheels:createPage({
        title = "Offload Animations",
        item = "minecraft:paper",
    })

    animationPage:addAction({
        title = "Stop Animation",
        item = "minecraft:barrier",
        onLeftClick = function()
            OffloadAnimations.stopAnimations()
        end
    })
    
    local modelAnimations = OffloadAnimations.getAllAnimationNames()
    for _, animationName in ipairs(modelAnimations) do
        animationPage:addAction({
            title = animationName,
            item = "minecraft:paper",
            onLeftClick = function()
                OffloadAnimations.playAnimation( animationName)
            end
        })
    end
end

vanilla_model.PLAYER:setVisible(false)